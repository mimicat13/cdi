# Imagemap-Generator
Source from Easy Imagemap Generator http://imagemap-generator.dariodomi.de/

 * Easy Imagemap Generator - Free Online Imagemapping Tool
 * build with
 *		-	PHP Logic
 *		-	jQuery Maphighlight Plugin
 *		-	CSS3
 *		-	Flash Uploadify
 *		-	HTML5 Upload
 * Date 	2012 for private use and since January 2013 for public
 * Version	v2.0
 * Copyright (c) by Dario D. Müller
 * Visit	http://dariodomi.de
 * GitHub -> https://github.com/DarioDomiDE/Imagemap-Generator