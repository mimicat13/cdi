<?php

// Config 
$uploadDir = './uploads';
$allowedTypes = array('jpg','jpeg','gif','png','bmp', 'tif', 'tiff'); // File extensions

